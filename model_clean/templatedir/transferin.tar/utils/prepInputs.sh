#!/bin/bash

tar -czf sample_inputs/elbow.tgz case

